# 🔐 Visual Cryptography & Steganography Toolkit

**UMT AI Department — Information Security (AI-4XXX) | Spring 2026**  
**Category B, Tier B | Instructor: Muhammad Zunnurain Hussain**

---

## 📋 Project Description

A comprehensive web-based toolkit demonstrating classical cryptography and modern steganography techniques with a built-in cryptanalysis dashboard.

---

## ✨ Features

### Classical Ciphers
| Cipher | Mode | Description |
|--------|------|-------------|
| Vigenère | Encrypt / Decrypt | Polyalphabetic substitution with repeating key |
| Playfair | Encrypt / Decrypt | Digraph substitution using 5×5 key table |
| Hill | Encrypt / Decrypt | Matrix multiplication mod 26 (3×3 default key) |

### Steganography Techniques
| Technique | Medium | Description |
|-----------|--------|-------------|
| LSB Substitution | PNG/BMP | Hides message in least significant pixel bits |
| DCT-based | PNG/BMP | Encodes in mid-frequency DCT coefficients |
| Unicode Homoglyphs | Text | Substitutes letters with visually identical Unicode chars |

### Cryptanalysis Tools
- Letter frequency analysis with English baseline comparison
- Index of Coincidence (IC) calculation
- Chi-squared test for English similarity
- Kasiski test for Vigenère key length estimation
- LSB steganalysis with PSNR and chi-squared metrics
- Detectability scoring system

---

## 🚀 Setup & Run

### Prerequisites
- Python 3.10+
- pip

### Installation

```bash
# Clone the repository
git clone https://github.com/<your-team>/stego-toolkit
cd stego-toolkit

# Install dependencies
pip install -r requirements.txt

# Run the app
streamlit run app.py
```

The app will open at `http://localhost:8501`

---

## 📁 Project Structure

```
stego_toolkit/
├── app.py              # Main Streamlit application
├── ciphers.py          # Vigenère, Playfair, Hill cipher implementations
├── steganography.py    # LSB, DCT, Unicode steganography
├── cryptanalysis.py    # Frequency analysis, IC, chi-squared tools
├── requirements.txt    # Python dependencies
├── README.md           # This file
└── tests/
    ├── test_ciphers.py         # Unit tests for all ciphers
    ├── test_steganography.py   # Unit tests for stego techniques
    └── test_cryptanalysis.py   # Unit tests for analysis tools
```

---

## 🧪 Running Tests

```bash
python -m pytest tests/ -v
```

---

## 🔐 Security Notes

- All operations are performed **client-side** within the Streamlit session
- No data is persisted or transmitted to external servers
- For educational and demonstration purposes only
- LSB steganography achieves PSNR > 50 dB (imperceptible to human eye)

---

## 📚 References

1. Morkel, T., Eloff, J.H.P., & Olivier, M.S. (2005). *An Overview of Image Steganography*. ISSA.  
2. Petitcolas, F.A.P., Anderson, R.J., & Kuhn, M.G. (1999). *Information Hiding—A Survey*. Proceedings of the IEEE.  
3. Wayner, P. (2009). *Disappearing Cryptography*. Morgan Kaufmann.  
4. Stallings, W. (2017). *Cryptography and Network Security*, 7th ed. Pearson.

---

## 👥 Team

| Name | Roll Number | Responsibility |
|------|-------------|----------------|
| Member 1 | — | Ciphers module + Hill implementation |
| Member 2 | — | Steganography module (LSB + DCT) |
| Member 3 | — | Cryptanalysis + UI/Streamlit dashboard |
| Member 4 | — | Text stego + testing + documentation |

---

*University of Management and Technology, Lahore | Spring 2026*
